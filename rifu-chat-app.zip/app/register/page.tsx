"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Loader2, CheckCircle } from "lucide-react"

export default function Register() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    userId: "",
    email: "",
    password: "",
    confirmPassword: "",
    verificationCode: "",
  })
  const [error, setError] = useState("")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (step === 1) {
      // Validate first step
      if (!formData.name || !formData.userId || !formData.email || !formData.password || !formData.confirmPassword) {
        setError("Please fill in all fields")
        return
      }

      if (formData.password !== formData.confirmPassword) {
        setError("Passwords do not match")
        return
      }

      setIsLoading(true)

      // Simulate API call to check if user ID is available
      setTimeout(() => {
        setIsLoading(false)
        setStep(2)
      }, 1500)
    } else {
      // Validate verification code
      if (!formData.verificationCode) {
        setError("Please enter the verification code")
        return
      }

      setIsLoading(true)

      // Simulate verification API call
      setTimeout(() => {
        // For demo purposes, accept any 6-digit code
        if (formData.verificationCode.length === 6) {
          // Store user info in localStorage (in a real app, use a more secure method)
          localStorage.setItem(
            "rifuUser",
            JSON.stringify({
              id: formData.userId,
              name: formData.name,
              email: formData.email,
            }),
          )
          setStep(3)
        } else {
          setError("Invalid verification code")
          setIsLoading(false)
        }
      }, 1500)
    }
  }

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-rose-50 to-pink-100 p-4 sm:p-6 md:p-8">
      {step !== 3 && (
        <Link
          href={step === 1 ? "/" : "#"}
          onClick={step === 2 ? () => setStep(1) : undefined}
          className="absolute top-4 left-4 flex items-center text-rose-600 hover:text-rose-700"
        >
          <ArrowLeft className="mr-1 h-4 w-4" />
          <span>{step === 1 ? "Back" : "Previous Step"}</span>
        </Link>
      )}

      <Card className="max-w-md w-full mx-auto my-auto">
        {step === 1 && (
          <>
            <CardHeader>
              <CardTitle className="text-2xl text-center text-rose-600">Create Account</CardTitle>
              <CardDescription className="text-center">Join Rifu to connect with friends and family</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    name="name"
                    placeholder="Enter your full name"
                    value={formData.name}
                    onChange={handleChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="userId">User ID</Label>
                  <Input
                    id="userId"
                    name="userId"
                    placeholder="Choose a unique user ID"
                    value={formData.userId}
                    onChange={handleChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="Enter your email"
                    value={formData.email}
                    onChange={handleChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    name="password"
                    type="password"
                    placeholder="Create a password"
                    value={formData.password}
                    onChange={handleChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm Password</Label>
                  <Input
                    id="confirmPassword"
                    name="confirmPassword"
                    type="password"
                    placeholder="Confirm your password"
                    value={formData.confirmPassword}
                    onChange={handleChange}
                  />
                </div>

                {error && <div className="text-sm text-red-500 mt-2">{error}</div>}

                <Button type="submit" className="w-full bg-rose-500 hover:bg-rose-600" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    "Continue"
                  )}
                </Button>
              </form>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4">
              <div className="text-sm text-center">
                Already have an account?{" "}
                <Link href="/login" className="text-rose-600 hover:underline">
                  Login
                </Link>
              </div>
            </CardFooter>
          </>
        )}

        {step === 2 && (
          <>
            <CardHeader>
              <CardTitle className="text-2xl text-center text-rose-600">Verify Your Account</CardTitle>
              <CardDescription className="text-center">
                We've sent a verification code to {formData.email}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="verificationCode">Verification Code</Label>
                  <Input
                    id="verificationCode"
                    name="verificationCode"
                    placeholder="Enter 6-digit code"
                    value={formData.verificationCode}
                    onChange={handleChange}
                    maxLength={6}
                  />
                </div>

                {error && <div className="text-sm text-red-500 mt-2">{error}</div>}

                <Button type="submit" className="w-full bg-rose-500 hover:bg-rose-600" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Verifying...
                    </>
                  ) : (
                    "Verify Account"
                  )}
                </Button>

                <div className="text-sm text-center">
                  Didn't receive a code?{" "}
                  <button type="button" className="text-rose-600 hover:underline">
                    Resend Code
                  </button>
                </div>
              </form>
            </CardContent>
          </>
        )}

        {step === 3 && (
          <>
            <CardHeader>
              <div className="flex justify-center mb-4">
                <CheckCircle className="h-16 w-16 text-green-500" />
              </div>
              <CardTitle className="text-2xl text-center text-rose-600">Account Created!</CardTitle>
              <CardDescription className="text-center">Your account has been successfully created</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <p className="mb-6">Welcome to Rifu, {formData.name}!</p>
              <Button onClick={() => router.push("/chat")} className="w-full bg-rose-500 hover:bg-rose-600">
                Start Chatting
              </Button>
            </CardContent>
          </>
        )}
      </Card>
    </div>
  )
}
