import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-br from-rose-50 to-pink-100">
      <main className="flex-1 flex flex-col items-center justify-center p-6 text-center">
        <div className="max-w-md w-full space-y-8 bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-xl">
          <div className="space-y-2">
            <h1 className="text-4xl font-bold tracking-tight text-rose-600">Rifu</h1>
            <p className="text-gray-600">Connect with friends, anytime, anywhere</p>
          </div>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-gray-500">Get started</span>
            </div>
          </div>

          <div className="space-y-4">
            <Button asChild className="w-full bg-rose-500 hover:bg-rose-600">
              <Link href="/login">Login</Link>
            </Button>
            <Button asChild variant="outline" className="w-full border-rose-200 text-rose-600 hover:bg-rose-50">
              <Link href="/register">Create Account</Link>
            </Button>
          </div>

          <div className="mt-6">
            <p className="text-sm text-gray-500">By signing up, you agree to our Terms of Service and Privacy Policy</p>
          </div>
        </div>
      </main>

      <footer className="py-4 text-center text-sm text-gray-500">
        © {new Date().getFullYear()} Rifu Chat. All rights reserved.
      </footer>
    </div>
  )
}
