"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Loader2 } from "lucide-react"

export default function Login() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [userId, setUserId] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!userId || !password) {
      setError("Please fill in all fields")
      return
    }

    setIsLoading(true)

    // Simulate login - in a real app, this would call an API
    setTimeout(() => {
      // For demo purposes, accept any login with user ID "demo" and password "password"
      if (userId === "demo" && password === "password") {
        // Store user info in localStorage (in a real app, use a more secure method)
        localStorage.setItem("rifuUser", JSON.stringify({ id: userId, name: "Demo User" }))
        router.push("/chat")
      } else {
        setError("Invalid user ID or password")
        setIsLoading(false)
      }
    }, 1500)
  }

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-rose-50 to-pink-100 p-4 sm:p-6 md:p-8">
      <Link href="/" className="absolute top-4 left-4 flex items-center text-rose-600 hover:text-rose-700">
        <ArrowLeft className="mr-1 h-4 w-4" />
        <span>Back</span>
      </Link>

      <Card className="max-w-md w-full mx-auto my-auto">
        <CardHeader>
          <CardTitle className="text-2xl text-center text-rose-600">Login to Rifu</CardTitle>
          <CardDescription className="text-center">
            Enter your user ID and password to access your account
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="userId">User ID</Label>
              <Input
                id="userId"
                placeholder="Enter your user ID"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <Link href="/forgot-password" className="text-xs text-rose-600 hover:underline">
                  Forgot password?
                </Link>
              </div>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            {error && <div className="text-sm text-red-500 mt-2">{error}</div>}

            <Button type="submit" className="w-full bg-rose-500 hover:bg-rose-600" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Logging in...
                </>
              ) : (
                "Login"
              )}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <div className="text-sm text-center">
            Don't have an account?{" "}
            <Link href="/register" className="text-rose-600 hover:underline">
              Create one
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}
