"use client"

import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Menu, MoreVertical } from "lucide-react"

interface MobileHeaderProps {
  toggleSidebar: () => void
  selectedContact: {
    id: string
    name: string
    lastSeen: string
    avatar: string
  }
  showSidebar: boolean
}

export default function MobileHeader({ toggleSidebar, selectedContact, showSidebar }: MobileHeaderProps) {
  if (showSidebar) {
    return null
  }

  return (
    <div className="fixed top-0 left-0 right-0 z-10 p-3 border-b border-gray-200 bg-white flex items-center">
      <Button variant="ghost" size="icon" onClick={toggleSidebar} className="mr-2">
        <Menu className="h-5 w-5" />
      </Button>

      <Avatar className="h-8 w-8 mr-2">
        <AvatarImage src={selectedContact.avatar || "/placeholder.svg"} alt={selectedContact.name} />
        <AvatarFallback>{selectedContact.name.charAt(0)}</AvatarFallback>
      </Avatar>

      <div className="flex-1">
        <h2 className="font-medium text-sm">{selectedContact.name}</h2>
        <p className="text-xs text-gray-500">{selectedContact.lastSeen}</p>
      </div>

      <Button variant="ghost" size="icon">
        <MoreVertical className="h-5 w-5" />
      </Button>
    </div>
  )
}
