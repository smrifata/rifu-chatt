import { Avatar, AvatarFallback } from "@/components/ui/avatar"

interface Message {
  id: number
  sender: string
  text: string
  timestamp: string
}

interface ChatMessageProps {
  message: Message
  isMe: boolean
  contactName: string
}

export default function ChatMessage({ message, isMe, contactName }: ChatMessageProps) {
  return (
    <div className={`flex ${isMe ? "justify-end" : "justify-start"}`}>
      <div className={`flex ${isMe ? "flex-row-reverse" : "flex-row"} max-w-[80%] items-end`}>
        {!isMe && (
          <Avatar className="h-8 w-8 mr-2">
            <AvatarFallback>{contactName.charAt(0)}</AvatarFallback>
          </Avatar>
        )}

        <div className={`flex flex-col ${isMe ? "items-end" : "items-start"}`}>
          <div
            className={`px-4 py-2 rounded-2xl ${
              isMe ? "bg-rose-500 text-white rounded-br-none" : "bg-white text-gray-800 rounded-bl-none"
            } shadow-sm`}
          >
            <p className="text-sm">{message.text}</p>
          </div>
          <span className="text-xs text-gray-500 mt-1 px-1">{message.timestamp}</span>
        </div>
      </div>
    </div>
  )
}
